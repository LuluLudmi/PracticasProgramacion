//paquete
package ClaseFor;

import java.util.Scanner;

/*
 
        Imprimir los números del 10 al 1, uno al lado
        del otro.
 */
public class ForParesEImpares {
    public static void main(String[] args) {
//        String msj = "";
//        
//        for (int i = 1; i <= 10; i++) {
//            msj += i + ","; // concatena los valores 
//        }
//        System.out.println(msj);
        
//        Imprimir la suma de los números impares del
//       1 al 10.

//        int nroImpar = 0;
//        for(int i=0; i<=10; i++){
//            if(i%2!=0){
//                nroImpar+=i;
//     

//        Declaramos la variables
        String msj = "";
        int impares = 0;
//
        for (int i = 1; i <= 10; i++) {
            msj += i + ",";
            if (i % 2 != 0) {
                impares = impares + i;
            }

        }
        System.out.println(msj);
        System.out.println("La suma de los impares es:" + impares);

//        Imprimir los números del 1 al 10, sin imprimir
//        números 2, 5 y 9, uno abajo del otro.
        Scanner teclado = new Scanner(System.in);

//      
//      for(int i=1; i<=10; i++){
//           if(i==2 || i==5 || i==9){            
//               continue;
//           }
//           System.out.println(i);
        }

    }
//}
 
    

