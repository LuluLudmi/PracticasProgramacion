/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.de.practica03;

/**
 *
 * @author Usuario
 */
public class EjercicioDePractica03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // 

        String palabra1 = "uesta";
        String palabra2 = "subir";
        String palabra3 = "la";
        String palabra4 = "a";
        String palabra5 = "e";
        String palabra6 = "l";
        String palabra7 = "v";
        String palabra8 = "s";
        String palabra9 = "n";
        String palabra10 = "c";
        String palabra11 = "d";
        String palabra12 = "y";
        String palabra13 = "medio";
        String palabra14 = ",";

        /*
        
         */
        System.out.println(palabra4.toUpperCase() + " " + palabra10.toUpperCase()
                + palabra1 + " " + palabra6 + palabra5 + " " + palabra10
                + palabra1 + " " + palabra2 + " " + palabra6 + palabra4
                + " " + palabra10 + palabra1 + " " + palabra12 + " " + palabra5
                + palabra9 + " " + palabra13 + " " + palabra3 + " " + palabra10
                + palabra1 + palabra14 + palabra7 + palabra4 + " " + palabra12
                + "" + " " + palabra8 + palabra5 + " " + palabra4 + palabra10 + palabra1);
        
       //Operadores Racionales
       /*
       <= menor o igual
       == igual
       != distinto
       son operadores binarios
       Los operadores
       */

    }

}
