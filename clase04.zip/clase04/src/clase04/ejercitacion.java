package clase04;

public class ejercitacion {

    /*
    
     */
    public static void main(String[] args) {

        // Ejercitacion 
        /*
        Dados num1=5, num2=10 y num3=20. Informar:
        a) n1+n2
        b) n3-n1
        c) n1*n3
        d) n3/n2

         */
        int nro1 = 5;
        int nro2 = 10;
        int nro3 = 20;

        System.out.println("suma;");
        System.out.println(nro1 + nro2);
        System.out.println("resta;");
        System.out.println(nro3 - nro1);
        System.out.println("multiplicacion;");
        System.out.println(nro1 * nro3);
        System.out.println("division;");
        System.out.println(nro3 / nro2);

        // 2
        /*
         Dados nro1=10, nro2=20 y nro3=30. Informar :
         a) El total de la suma de todas las variables
         b) El promedio
         c) El resto entre n2 y n1
         */
        System.out.println(nro1 += 5);
        System.out.println(nro2 += 10);
        System.out.println(nro3 += 10);
        System.out.println("suma");
        System.out.println(nro1 + nro2 + nro3);
        System.out.println("resto");
        System.out.println(nro2 % nro1);
        // 3
        /*
        Declarar dos variables n1=5 y n2=10.
        Utlizando concatenaci�n entre las variables y los literales, mostrar en
        pantalla la siguiente expresi�n:
        n1 es igual a 5,n2 es igual a 10 y n1 m�s n2 es igual a 15.
         */
        int n1 = 5;
        int n2 = 10;

        System.out.println(n1);
        System.out.println(n2);
        System.out.println(n1 + n2);

        //4
        /*
         Haciendo uso de la constante IVA=21, calcular el precio con IVA de los siguientes productos e 
         informar: 
         a) remera:$59.90 
         b) pantal�n:$99.90 
         c) campera:$149.90
         */
        
          float r =59.90f;
          float p = 99.90f;
          float c = 149.90f;
          int n3 = 21;
          int n4 = 100;  
          
          System.out.println(r*n3/n4+r);
          System.out.println(p*n3/n4+p);
          System.out.println(c*n3/n4+c);
          
    }

}
