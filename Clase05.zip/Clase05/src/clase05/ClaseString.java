/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clase05;

/**
 *
 * @author alumno
 */
public class ClaseString {
    public static void main(String[] args) {
                /*
      
        Convenciones de escritura
        camel case -> estaEsUnaFraseEnCameCase(lower camel case)
        pascal case -> EstaEsUnaFraseEnPascalCase(upper camel case)
        snake_case -> esta_es_una_frase_en_snake_case(upper camel case)
        
        */
        System.out.println("Clase String");
        //la clase String contiene un vector de caracteres
        
        //podemos crear un objeto de la clase String de varias maneras
        
        String texto1= "Cadena de Texto";
        String texto2 = new String ("hola");
        String texto3 = "hola";
        
        // metodos para comparar
        
        System.out.println(texto3=="hola");
        System.out.println(texto2=="hola");
        //el operador de comparacion == compara que sean el mismo espacio
        //en memoria.
        
        //para poder comparar cadenas e caracteres teniendo en cuenta
        //su contenido, se utilizan los metodos . equals() .equalsIgnoreCase()
        
        System.out.println(texto2.equals("hola"));
        System.out.println(texto3.equals("hola"));
        System.out.println(texto2.equals(texto3));
        System.out.println(texto2.equals("Hola"));
        
        //para ignorar las mayusculas y minusculas
        // utilizamos . equalsIgnoreCase()
        System.out.println(texto2.equalsIgnoreCase("Hola"));// true
        
        //.contains()
        //devuelve un booleano indicando si la cadena, contienen la
        //subcadena dada
        System.out.println(texto1.contains("hola"));
        System.out.println(texto2.contains("ol"));
        System.out.println(texto2.contains("lo"));
        
        //.length()
        
        
        System.out.println(texto1.length());//16
        System.out.println(texto2.length());//4
        
        //.isEmpty()
        //devuelve un booleano indicando si la cadena esta vacia
        //es deir, si  su longitud es igual a 0
        System.out.println(texto1.isEmpty());// falso
        
        
       //.isBank() aparece a partir del jdk 11
       //devuelve un booleano que indica si la cadena esta vacia
       //o si solo contiene espacios en blanco, o si solo contiene
       // saltos de linea o tabulaciones.
       String texto4 = " ";
        System.out.println(texto4.isEmpty());// false
        System.out.println(texto4.isBlank()); // true
        
        //.charAt()
        //devuelve el caracter del indice dado
       
        System.out.println(texto1.charAt(7));//d
        System.out.println(texto2.charAt(2));//l
        //System.out.println(texto2.charAt(5));
        //la anterior sentencia arroja error porque no existe
        //la posicion 5 para un vector de longitud 4
        
        //.indeOf()
        //devuelve el indice de la primera ocurrencia de la subcadena
        //sino la encuentra, devuelve -1
        System.out.println(texto1.indexOf("texto"));// -1 
        //porque la T es mayuscula en texto1
        System.out.println(texto1.indexOf("e"));//3
                
                
       
    }
}
