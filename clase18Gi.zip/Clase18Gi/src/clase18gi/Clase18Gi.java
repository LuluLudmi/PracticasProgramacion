//paquete
package clase18gi;

public class Clase18Gi {

    public static void main(String[] args) {
        System.out.println("Funciones y procedimientos");
        /*
        Las funciones y procedimientos son un bloque de codigo que contiene
        una o mas instrucciones, al cual podemos invocar para que sean ejecutadas.
        Las funciones y los procedimientos nos ayudan a hacr que nuestro codigo 
        sea mas legible y que evitemos tener codigo duplicado
         */
        System.out.println("Funciones");
        /*Las funciones siempre retoman un valor. 
         En su declaracion deben indicar que tipo e valor retornan
         En su cuerpo deben contener la sentencia return con el retorno
         del tipo de dato que se indico en su  cabecera.
         */
        int numero = retornarNumeroDiez();
        System.out.println(numero);

        int segundoNumero = 30;
        int resultado = sumarDosNumerosEnteros(numero, segundoNumero);
        System.out.println(resultado);

        resultado = sumarDosNumerosEnteros(10, 20);
        System.out.println(resultado);
        resultado = sumarDosNumerosEnteros(retornarNumeroDiez(), 50);
        System.out.println(esPar(15));
        System.out.println(esPar(retornarNumeroDiez()));

        System.out.println("******");
        System.out.println("Procedimientos");
        /*
        Los procedimiento no tienen retorno.
        En su declaracion deben llevar la palabra reserva void
        para indicar que no tienen retorno.
         */
        
        saludar();
        
        
        
        
        
        
    }// fin del metodo main
    // Ejemplos de funciones

    public static int retornarNumeroDiez() {//Debo declarar que va retormar la funcion
        return 10;
    }

    public static int sumarDosNumerosEnteros(int numero1, int numero2) {
        int suma = numero1 + numero2;
        return suma;

    }

    public static boolean esPar(int numero) {
//        if (numero % 2 == 0) {
//             return true;
//        }else{
//            return false;
//        }
//    }
        return numero % 2 == 0;
    }
    //Ejemplos de procedimientos

    public static void saludar() {
        System.out.println("Hola Mundo!");
    }
} //fin de la clase

