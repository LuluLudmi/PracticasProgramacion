

package clase06;


public class ClaseString {
    public static void main(String[] args) {
        /*
        Convenciones de escritura
        camel case -> estaEsUnaFraseEnCamelCase (lower camel case)
        pascal case -> EstaEsUnaFraseEnCamelCase (upper camel case)
        snake_case -> esta_es_una_frase_en_snake_case
        */
        
        System.out.println("Clase String");
        //la clase String contiene un vector de caracteres
        
        //podemos crear un objeto de la clase String de varias maneras
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //m�todos para comparar
        System.out.println(texto3 == "hola"); //true
        System.out.println(texto2 == "hola"); //false
        //el operador de comparaci�n == compara que sean el mismo espacio
        //en memoria.
        
        //para poder comparar cadenas de caracteres teniendo en cuenta
        //su contenido, se utilizan los m�todos .equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        System.out.println(texto3.equals("hola")); //true
        System.out.println(texto2.equals(texto3)); //true
        System.out.println(texto2.equals("Hola")); //false
        //para ignorar las may�sculas y min�sculas
        //utilizamos .equalsIgnoreCase()
        System.out.println(texto2.equalsIgnoreCase("Hola")); //true
        
        //.contains()
        //devuelve un booleano indicando si la cadena, contiene la
        //subcadena dada
        System.out.println(texto1.contains("hola")); //false            
        System.out.println(texto2.contains("ol")); //true
        System.out.println(texto2.contains("lo")); //false
        
        //.length()
        //devuelve un n�mero entero que representa la longitud del vector
        //es decir, cu�ntos caracteres tiene la cadena
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //devuelve un booleano indicando si la cadena est� vac�a
        //es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //falso
        
        //.isBlank() aparece a partir del JDK 11
        //devuelve un booleano que indica si la cadena est� vac�a
        //o si solo contiene espacios en blanco, o si solo contiene
        //saltos de l�nea o tabulaciones.
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true
        
        //.charAt() 
        //devuelve el caracter del �ndice dado
        System.out.println(texto1.charAt(7)); //d
        System.out.println(texto2.charAt(2)); //l
        //System.out.println(texto2.charAt(4)); //l
        //la anterior sentencia arroja error porque no existe
        //la posici�n 5 para un vector de longitud 4
        
        //.indexOf()
        //devuelve el �ndice de la primera ocurrencia de la subcadena
        //si no la encuentra, devuelve -1
        System.out.println(texto1.indexOf("texto")); //-1 
        // porque la t es may�scula en texto1
        System.out.println(texto1.indexOf("e")); //
        
        //.trim()
        //quita los espacios de adelante y de atr�s
        System.out.println("   Hola Mundo!   ");
        System.out.println("   Hola Mundo!   ".trim());
        
        //.startsWith() .endsWith()
        //devuelven un booleano indicando si la cadena comienza o finaliza con 
        //un texto determinado pasado como par�metro
        System.out.println(texto1.startsWith("ola")); //false
        System.out.println(texto1.startsWith("hola")); //false
        System.out.println(texto2.startsWith("ho")); //true
        System.out.println(texto1.endsWith("texto")); //false
        System.out.println(texto1.endsWith("Texto!")); //true
        
        //m�todos para reemplazar
        //.replace()
        //reemplaza un caracter por otro
        System.out.println(texto1.replace('e', 'i')); 
        //tambi�n puede reemplazar una cadena por otra
        System.out.println(texto1.replace("Texto", "caracteres"));
        //.replaceFirst()
        //reemplaza s�lo la primera vez que aparezca la subcadena
        texto3 = "manzana, manzana, naranja";
        System.out.println(texto3.replaceFirst("manzana", "banana"));
        //.replaceAll()
        //reemplaza todas las veces que aparezca la subcadena
        System.out.println(texto3.replaceAll("manzana", "banana"));
        
        //si bien el m�todo .replace() tambi�n reemplaza todas las veces que aparezca
        //la subcadena, el m�todo .replaceAll() es mucho m�s potente ya que permite
        //buscar y reemplazar patrones de expresiones regulares
        //Una expresi�n regular es una secuencia de caracteres que definen un patr�n
        //de b�squeda
        String texto5 = "Mi n�mero de tel�fono es 011-8888-9999. Y mi n�mero laboral"
                + "es 011-9999-8888.";
        System.out.println(texto5.replaceAll("\\d{3}-\\d{4}-\\d{4}", "HIDDEN INFORMATION"));
        
        //.repeat()
        //repite la cadena la cantidad de veces que le indiquemos por par�metro
        System.out.println(texto2.repeat(3));
        
        //ya hemos visto .toLowerCase() y .toUpperCase()
                
        //.substring()
        //devuelve una subcadena de la cadena principal
        System.out.println(texto1.substring(10));
        //lo que se indica como par�metro es el �ndice de donde comienza la subcadena
        //otro comportamiento del m�todo susbtring() es que puedo pasarle dos 
        //n�meros enteros como par�metros indicando de d�nde y hasta d�nde quiero
        //que sea la subcadena.
        //Ojo, no puedo pasarme de �ndice porque da una exception
        System.out.println(texto1.substring(3, 9));
        
        //catacteres de escape
        /*
        Los caracteres de escape son secuencias especiales de caracteres que se utilizan
        en cadenas de texto y literales de caracteres, para representar caracteres
        especiales o caracteres que no se pueden representar ditectamente.
        Los caracteres de escape comienzan con una barra invertida \ seguida de un 
        caracter que indica qu� tipo de escape se est� utilizando.
        */
        
        // \n salto de l�nea
        System.out.println("Hola\nMundo!");
        
        // \t tabulaci�n
        System.out.println("Hola\tMundo!");
        
        // \" comillas dobles
        System.out.println("\"Hola Mundo!\"");
        
        // \' comillas simples
        System.out.println("\'Hola Mundo!\'");
        
        // \\ contrabarra o barra invertida
        System.out.println("\\Hola Mundo!\\");
        
    }
}
