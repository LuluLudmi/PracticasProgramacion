//Paquete
package problemas_de_youtube;

import java.util.Scanner;

// Una tienda ofrece un descuento del 15% sobre el total de la compra durante
//el mes de octubre. Dado un mes y un importe, calcular cuál es la cantidad que
//se debe cobrar al cliente.
public class Problemas_de_youtube {
//Metodo Main

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        
        double importedecompra,total;
        double descuento;
        
//    
        
        System.out.println("Ingrese el importe de compra:");
        importedecompra = teclado.nextDouble();
        System.out.println("Ingrese el descuento a realizar:");
        descuento= teclado.nextDouble();
        double descuentoARealizar = importedecompra/100*descuento;
        System.out.println("Representa un descuento de $:" + descuentoARealizar);
        importedecompra += descuentoARealizar;
        total= importedecompra- descuentoARealizar;
        
        System.out.println("Total de la compra con descuento:"+ total);
        
    
//      
//        double interesMensual = montoAcumulado / 100 * interes;
//        System.out.println("Que representa una ganancia de: $" + interesMensual);
//        montoAcumulado += interesMensual;

        //Otra opcion
//        double compraSinDescuento;
//        double descuentoRealizado;
//        double totalidad=100;
//        
//        
//        System.out.println("Ingrese la compra sin descuento");
//        compraSinDescuento=teclado.nextDouble();
//        System.out.println("Ingrese el descuento a realizar:");
//        descuentoRealizado=teclado.nextDouble();
//        System.out.println("Importe con descuento:");
//        compraSinDescuento=compraSinDescuento-(compraSinDescuento*.15);
//        total=compraSinDescuento;
//        System.out.println("Este fue el descuento:" + (compraSinDescuento*descuentoRealizado)/totalidad);
    }

}
