
package clase07;


public class Clase05 {


    public static void main(String[] args) {
        /*
        1-
        Dados num1=5, num2=10 y num3=20. Informar:
        a) num1+num2
        b) num3-num1
        c) num1*num3
        d) num3/num2
        */
        
        
        int num1 = 5;
        int num2 = 10;
        int num3 = 20;
        
        //int num1=5, num2=10, num3=20;
        
        System.out.print("El resultado de num1 + num2 es: ");
        System.out.println(num1 + num2);
        System.out.print("El resultado de num3 - num1 es: ");
        System.out.println(num3 - num1);
        System.out.print("El resultado de num1 * num3 es: ");
        System.out.println(num1 * num3);
        System.out.print("El resultado de num3 / num2 es: ");
        System.out.println(num3 / num2);
        
        
        /*
        2-
        Dados nro1=10, nro2=20 y nro3=30. Informar :
        a) El total de la suma de todas las variables
        b) El promedio
        c) El resto entre nro2 y nro1
        */
        
        System.out.println("");
        System.out.println("*************************");
        System.out.println("");
        
        int nro1 = 100;
        int nro2 = 20;
        int nro3 = 30;
        
        int sumaTotal = nro1 + nro2 + nro3;
        int promedio = sumaTotal / 3;
        int resto = nro2 % nro3;
        
        System.out.println("El total de la suma es: " + sumaTotal);
        System.out.println("El promedio es: " + promedio);
        System.out.println("El resto es: " + resto);
        
        System.out.println("");
        System.out.println("*************************");
        System.out.println("");
        
        /*
        3-
        Declarar dos variables n1=5 y n2=10.
        Utilizando concatenaci�n entre las variables y los literales, 
        mostrar en pantalla la siguiente expresi�n:
        n1 es igual a 5, n2 es igual a 10 y n1 m�s n2 es igual a 15.
        */
        
        int n1 = 5;
        int n2 = 10;
        
        System.out.println("n1 es igual a " + n1 + ", n2 es igual a " + n2
                            + " y n1 m�s n2 es igual a " + (n1+n2));
        
        System.out.println("");
        System.out.println("*************************");
        System.out.println("");
        
        /*
        4-
        Haciendo uso de la constante IVA=21, calcular el precio con IVA de los
        siguientes productos e informar:
        a) remera:$59.90
        b) pantal�n:$99.90
        c) campera:$149.90
        */
        
        final int IVA = 21;
        double remera = 59.90;
        double pantalon = 99.90;
        double campera = 149.90;
        
        System.out.println("El precio de la remera con el IVA es de " + 
                ((remera * IVA / 100 ) + remera));
        System.out.println("El precio del pantal�n con el IVA es de " + 
                ((pantalon * IVA / 100 ) + pantalon));
        System.out.println("El precio de la remera con el IVA es de " + 
                ((campera * IVA / 100 ) + campera));
        
        
        
    }
    
}

