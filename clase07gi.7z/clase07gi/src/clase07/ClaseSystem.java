
package clase07;
import java.util.Scanner;

public class ClaseSystem {
    public static void main(String[] args) {
        System.out.println("** Clase System**");
        /*
        la calse system es un intermediario entre la maquina virtual de 
        Java 
        */
        
        //los atributos ms clasicos son out,err,in
        // representan streams de entrada y salida
        // son atributos finales y estatcos
        // out es un stream de salida sincroizado
        // err es stream de salida desinronizado
        
        /* Stream (flujo o Corriente ) es una secuencia de datos que se procesa
        o transmite de manera secuencial, en lugar de cargarse o procesarse
        en su totalidad antes de utilizarse.
        */
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        System.err.println("Ocurrio un error!");
        
        
        
        //el parametro o indica que el programa finalizo sin errores
        //el 1 seria si hubiera errores
        // el -1 seria por advertencias
        
        //.getProperties()
        // representa un mapa o ector asociativo que es igual
        //en todas las configuraciones
        
        System.out.println(System.getProperties());//propiedades del sistema
        System.out.println(System.getProperty("os.name"));//nombre del SO
        System.out.println(System.getProperty("os.version"));//version de
        System.out.println(System.getProperty("os.arch"));//arquitectura
        System.out.println(System.getProperty("java.version"));//version de
        System.out.println(System.getProperty("os.version"));//version de
        System.out.println(System.getProperty("user.name"));//usuario
        System.out.println(System.getProperty("user.home"));//directorio
        
        //Clase Sanner
        System.out.println("** Clase Scanner**");
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Ingrese su nombre:");
        String nombre = teclado.next();//captura el teto hasta el primer espacio
        //el metodo. next() detiene el hilo de la ejecucion, el programa
        
        
        System.out.println("Su nombre es"+ nombre);
        
        System.out.println("Ingrese su nombre y apellido");
        teclado.nextLine();
        String nombreCompleto = teclado.nextLine();// captura toda la linea
        System.out.println("Su nombre completo es:"+ nombreCompleto);
        
        System.out.println("Ingrese su edad:");
        int edad = teclado.nextInt();
        System.out.println("Su edad es:" + edad + "a�os");
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }

}
