
package cursojava.tecnicas.condicionales;


public class EstructurasIf {
    public static void main(String[] args) {
        //estructuras condicionales
        
        //estructura if
        int num1 =150;
        int num2=20;
         System.out.println("Estructuras if");
         if(num1>num2){
             System.out.println("El num1 es mayor al num2");
         }
         System.out.println("Fin de la estructura if");
         
         if(num1!=20){
             System.out.println("El num1 no es igual a 20");
         }
         boolean log1 = true;
         if(log1 = true);
         
         if(log1){ // los valores booleanos, o se comparan con true y false
             System.out.println("log1 es verdadera");
         }
         //if en linea 
         if(num1> 100 && num2== 20) System.out.println("Imprimo en linea");
         
     
         }
        
                
    }

