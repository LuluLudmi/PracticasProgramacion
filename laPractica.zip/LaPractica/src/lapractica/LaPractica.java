/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lapractica;

public class LaPractica {

    public static void main(String[] args) {

        int num1 = 80;
        int num2 = 60;

        if (num2 > num1) {
            System.out.println("El numero 2 es mayor numero 1");
        } else {
            if (num2 == num1) {
                System.out.println("el numero 2 es igual a numero 1");
            } else {

                System.out.println("El numero 1 es mayor a numero 2");

            }

        }
    }

}
