//paquete
package ClaseFor;

import java.util.Scanner;

/*
 
        Imprimir los números del 10 al 1, uno al lado
        del otro.
 */
public class ForParesEImpares {

    public static void main(String[] args) {
//        String msj = "";
//        
//        for (int i = 1; i <= 10; i++) {
//            msj += i + ","; // concatena los valores 
//        }
//        System.out.println(msj);

//        Imprimir la suma de los números impares del
//       1 al 10.
//        int nroImpar = 0;
//        for(int i=0; i<=10; i++){
//            if(i%2!=0){
//                nroImpar+=i;
//     
//        Declaramos la variables
//
//        for (int i = 1; i <= 10; i++) {
//            
//            if (i % 2 != 1) {
//                continue;
//            }
//         System.out.println(i);
//       
//        }
//        
//        Imprimir los números del 1 al 10, sin imprimir
//        números 2, 5 y 9, uno abajo del otro.
        Scanner teclado = new Scanner(System.in);
        /*
        Imprimir los números del 1 al 30 sin imprimir
        números entre el 10 y el 20 uno abajo del otro
         */

//     for(int i=1; i<=30; i++){
//         if(i<=10 || i>=20){            
//              continue;
//          }
//          System.out.println(i);
//        }
//        Imprimir los números del 1 al 10 salteando de
//        a dos, uno abajo del otro.
//        for (int i = 1; i <= 10; i+=2) {
//            System.out.println(i);
//        }
//        System.out.println("Fin de la estructura for");
//        Imprimir los números del 10 al 1, uno al lado del otro.
        //String msj = "";

//        for (int i = 1; i <= 10; i++) {
//            msj += i + ",";
//        }
//        System.out.println(msj);
//        
        // while 
        int numero = 1;
        
         while (numero <= 10){
             System.out.println(numero);
             numero ++;
         }
         /*
          
         */
         
    }
}
