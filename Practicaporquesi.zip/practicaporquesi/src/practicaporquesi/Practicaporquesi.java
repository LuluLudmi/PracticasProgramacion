/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practicaporquesi;

/**
 *
 * @author Usuario
 */
public class Practicaporquesi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       /*
        Ejercicio 4
        // sacar el iva de determinados productos
        */
       final double IVA = 21; // Uso double porque el valor del iva puede variar
       float remera = 59.90f;
       float pantalon = 99.90f;
       float campera = 149.90f;
       
       System.out.println("El precio final de la remera con IVA es:" +((remera/100)*IVA)+ remera);
       
    }
    
}
