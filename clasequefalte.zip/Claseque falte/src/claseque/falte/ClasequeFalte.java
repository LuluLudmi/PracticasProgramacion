/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package claseque.falte;

/**
 *
 * @author Usuario
 */
public class ClasequeFalte {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("** Clase System **");
        
        /*
        La clase System es un intermediario entre la máquina virtual de Java
        y el entorno de ejecución en el que estamos ejecutando nuestro programa.
        Como la máquina virtual de Java puede ejecutarse en múltiples plataformas,
        la clase System nos abstrae de la plataforma sobre la que se esté ejecutando.
        */
        
        //Los atributos más clásicos son out, err, in
        //representan streams de entrada y salida
        //son atributos finales y estáticos
        //out es un stream de salida sincronizado
        //err es un stream de salida desincronizado
        
        /*
        Stream (flujo o corriente) es una secuencia de datos que se procesa
        o transmite de manera secuencial, en lugar de cargarse o procesarse
        en su totalidad antes de utilizarse
        */
        
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        System.err.println("Ocurrió un error!");
        
     
       
        
    }
    
}
